package com.sinfloo.demo;

import java.util.List;

public interface ipersonaservice {

	public List<persona>listar();
	public int save(persona p);
	public void delete(int id);
	
}
