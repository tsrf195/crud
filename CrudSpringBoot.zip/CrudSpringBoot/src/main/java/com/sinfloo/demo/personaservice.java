package com.sinfloo.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class personaservice implements ipersonaservice{

	@Autowired
	private  ipersona data;
	
	@Override
	public List<persona> listar() {
		return (List<persona>)data.findAll();
	}

	@Override
	public int save(persona p) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

}
